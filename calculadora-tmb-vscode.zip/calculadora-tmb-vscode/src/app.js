const app = document.querySelector('#app')
const toast = document.querySelector('#toast')

const ICONS = {
  home: 'M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z',
  calculator:
    'M19 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V5a2 2 0 0 0-2-2m-5.97 4.06L14.09 6l1.41 1.41L16.91 6l1.06 1.06-1.41 1.41 1.41 1.41-1.06 1.06-1.41-1.41-1.41 1.41-1.06-1.06 1.41-1.41zM6.25 7.72h5v1.5h-5zM11.5 16h-2v2H8v-2H6v-1.5h2v-2h1.5v2h2zm6.5 1.25h-5v-1.5h5zm0-2.5h-5v-1.5h5z',
  history:
    'M13 3a9 9 0 0 0-9 9H1l3.89 3.89.07.14L9 12H6a7 7 0 1 1 2.06 4.94l-1.42 1.42A9 9 0 1 0 13 3m-1 5v5l4.28 2.54.72-1.21-3.5-2.08V8z',
  profile:
    'M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8m0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4',
  email:
    'M20 4H4a2 2 0 0 0-1.99 2L2 18a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2m0 4-8 5-8-5V6l8 5 8-5z',
  lock: 'M18 8h-1V6A5 5 0 0 0 7 6v2H6a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V10a2 2 0 0 0-2-2m-6 9a2 2 0 1 1 0-4 2 2 0 0 1 0 4m3.1-9H8.9V6a3.1 3.1 0 1 1 6.2 0z',
  logout:
    'm17 7-1.41 1.41L18.17 11H8v2h10.17l-2.58 2.58L17 17l5-5zM4 5h8V3H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h8v-2H4z',
  chevron: 'm10 6-1.41 1.41L13.17 12l-4.58 4.59L10 18l6-6z',
  check: 'm9 16.17-4.17-4.17-1.42 1.41L9 19 21 7l-1.41-1.41z',
}

const state = {
  route: 'home',
  sex: 'Masculino',
  selectedHistory: 0,
  result: null,
}

function icon(name, className = '') {
  return `<svg class="${className}" viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="${ICONS[name]}"/></svg>`
}

function getConfig() {
  return window.APP_CONFIG || {}
}

function getSession() {
  try {
    return JSON.parse(localStorage.getItem('tmb_session')) || null
  } catch {
    return null
  }
}

function setSession(session) {
  localStorage.setItem('tmb_session', JSON.stringify(session))
}

function historyKey() {
  return `tmb_history_${getSession()?.email || ''}`
}

function getHistory() {
  try {
    const history = JSON.parse(localStorage.getItem(historyKey())) || []
    return Array.isArray(history) ? history : []
  } catch {
    return []
  }
}

function addHistory(tmb, sex) {
  const history = [{ tmb: Math.round(tmb), sex, date: Date.now() }, ...getHistory()].slice(0, 30)
  localStorage.setItem(historyKey(), JSON.stringify(history))
}

function displayName(email = '') {
  const username = email.split('@')[0]
  const pieces = username.split(/[._-]+/).filter(Boolean)
  if (!pieces.length) return 'Usuário'
  return pieces.map((piece) => piece[0].toUpperCase() + piece.slice(1).toLowerCase()).join(' ')
}

function initials(name) {
  const pieces = name.split(' ').filter(Boolean)
  return `${pieces[0]?.[0] || 'U'}${pieces.length > 1 ? pieces.at(-1)[0] : ''}`.toUpperCase()
}

function formatDate(timestamp, short = false) {
  const date = new Date(timestamp)
  if (short) {
    return new Intl.DateTimeFormat('pt-BR', { day: '2-digit', month: '2-digit' }).format(date)
  }
  const day = new Intl.DateTimeFormat('pt-BR', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
  }).format(date)
  const time = new Intl.DateTimeFormat('pt-BR', {
    hour: '2-digit',
    minute: '2-digit',
  }).format(date)
  return `${day} às ${time}`
}

let toastTimer
function showToast(message) {
  toast.textContent = message
  toast.classList.add('visible')
  clearTimeout(toastTimer)
  toastTimer = setTimeout(() => toast.classList.remove('visible'), 3200)
}

function bytesToBase64(bytes) {
  let binary = ''
  for (const byte of bytes) binary += String.fromCharCode(byte)
  return btoa(binary)
}

function base64ToBytes(value) {
  const binary = atob(value)
  return Uint8Array.from(binary, (character) => character.charCodeAt(0))
}

async function transportKey() {
  const value = getConfig().API_TRANSPORTE_KEY
  const raw = base64ToBytes(value)
  if (raw.byteLength !== 32) throw new Error('A chave de transporte precisa ter 32 bytes em Base64.')
  return crypto.subtle.importKey('raw', raw, 'AES-GCM', false, ['encrypt', 'decrypt'])
}

async function seal(payload) {
  const iv = crypto.getRandomValues(new Uint8Array(12))
  const plain = new TextEncoder().encode(JSON.stringify({ ...payload, ts: Date.now() }))
  const encrypted = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, await transportKey(), plain)
  return {
    iv: bytesToBase64(iv),
    data: bytesToBase64(new Uint8Array(encrypted)),
  }
}

async function open(envelope) {
  const plain = await crypto.subtle.decrypt(
    { name: 'AES-GCM', iv: base64ToBytes(envelope.iv) },
    await transportKey(),
    base64ToBytes(envelope.data),
  )
  return JSON.parse(new TextDecoder().decode(plain))
}

async function apiRequest(endpoint, credentials) {
  if (getConfig().API_MODE !== 'server') {
    return localRequest(endpoint, credentials)
  }

  const baseUrl = String(getConfig().API_BASE_URL || '').replace(/\/$/, '')
  if (!baseUrl) throw new Error('Configure a API_BASE_URL no index.html.')
  if (!getConfig().API_TRANSPORTE_KEY) {
    throw new Error('Configure a API_TRANSPORTE_KEY para usar o modo servidor.')
  }
  const response = await fetch(`${baseUrl}${endpoint}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(await seal(credentials)),
  })
  const body = await open(await response.json())
  if (!response.ok) throw new Error(body.error || `Erro ${response.status}`)
  return body
}

function localRequest(endpoint, credentials) {
  if (endpoint === '/register') {
    return Promise.resolve({ message: 'Conta criada com sucesso neste dispositivo' })
  }

  const tokenBytes = crypto.getRandomValues(new Uint8Array(24))
  return Promise.resolve({
    access_token: `local_${bytesToBase64(tokenBytes)}`,
    email: credentials.email,
  })
}

function renderLogin() {
  app.innerHTML = `
    <section class="login-page">
      <form class="login-content" id="login-form">
        <div class="app-icon">${icon('lock')}</div>
        <h1 class="large-title login-title">Bem-vindo</h1>
        <p class="subtitle login-subtitle">Entre com sua conta para continuar</p>
        <div class="card login-card">
          <input class="field" id="email" type="email" autocomplete="email" placeholder="Email" aria-label="Email" required>
          <div class="divider"></div>
          <input class="field" id="password" type="password" autocomplete="current-password" placeholder="Senha" aria-label="Senha" minlength="6" required>
        </div>
        <button class="primary-button login-button" type="submit">Entrar</button>
        <button class="text-button" id="register" type="button">Criar conta</button>
      </form>
    </section>
  `

  const form = document.querySelector('#login-form')
  form.addEventListener('submit', (event) => authenticate(event, '/login'))
  document.querySelector('#register').addEventListener('click', (event) => authenticate(event, '/register'))
}

async function authenticate(event, endpoint) {
  event.preventDefault()
  const emailInput = document.querySelector('#email')
  const passwordInput = document.querySelector('#password')
  const email = emailInput.value.trim().toLowerCase()
  const password = passwordInput.value

  if (!email) return showToast('Digite o email')
  if (!password) return showToast('Digite a senha')
  if (password.length < 6) return showToast('A senha precisa ter pelo menos 6 caracteres')

  const buttons = [...document.querySelectorAll('#login-form button')]
  buttons.forEach((button) => (button.disabled = true))
  try {
    const response = await apiRequest(endpoint, { email, password })
    if (endpoint === '/register') {
      showToast(response.message || 'Conta criada com sucesso!')
      return
    }
    setSession({
      accessToken: response.access_token,
      email: response.email || email,
      lastAccess: Date.now(),
    })
    showToast('Login realizado com sucesso!')
    renderApp()
  } catch (error) {
    showToast(error.message || 'Falha na conexão com o servidor')
  } finally {
    buttons.forEach((button) => (button.disabled = false))
  }
}

function navTemplate() {
  const items = [
    ['home', 'Início', 'home'],
    ['calculator', 'Calcular', 'calculator'],
    ['history', 'Histórico', 'history'],
    ['profile', 'Perfil', 'profile'],
  ]
  return `
    <nav class="bottom-nav" aria-label="Navegação principal">
      ${items
        .map(
          ([route, label, iconName]) => `
            <button class="nav-item ${state.route === route ? 'active' : ''}" data-route="${route}" type="button" ${state.route === route ? 'aria-current="page"' : ''}>
              <span class="nav-icon">${icon(iconName)}</span>
              <span>${label}</span>
            </button>
          `,
        )
        .join('')}
    </nav>
  `
}

function renderApp() {
  if (!getSession()) return renderLogin()
  const routes = {
    home: homeTemplate,
    calculator: calculatorTemplate,
    history: historyTemplate,
    profile: profileTemplate,
  }
  app.innerHTML = `<div class="app-shell">${routes[state.route]()}${navTemplate()}</div>`
  bindCommonEvents()
  if (state.route === 'calculator') bindCalculator()
  if (state.route === 'history') bindHistory()
  if (state.route === 'profile') bindProfile()
}

function bindCommonEvents() {
  document.querySelectorAll('[data-route]').forEach((element) => {
    element.addEventListener('click', () => {
      state.route = element.dataset.route
      if (state.route === 'history') state.selectedHistory = Math.max(0, getHistory().length - 1)
      renderApp()
      window.scrollTo({ top: 0, behavior: 'smooth' })
    })
  })
}

function homeTemplate() {
  const session = getSession()
  const name = displayName(session.email)
  const history = getHistory()
  return `
    <section class="screen">
      <div class="screen-content">
        <p class="subtitle">Bem-vindo(a) de volta</p>
        <h1 class="large-title">Olá, ${name.split(' ')[0]}</h1>

        <button class="card user-card clickable" data-route="profile" type="button">
          <span class="avatar">${initials(name)}</span>
          <span class="user-copy">
            <span class="user-name">${escapeHtml(name)}</span>
            <span class="subtitle user-email">${escapeHtml(session.email)}</span>
          </span>
          ${icon('chevron', 'chevron')}
        </button>

        <h2 class="section-header">Resumo</h2>
        <div class="summary-grid">
          <div class="card summary-card">
            <p class="summary-label">Última TMB</p>
            <p class="summary-value">${history[0]?.tmb ?? '—'}</p>
            <p class="summary-footnote">kcal por dia</p>
          </div>
          <div class="card summary-card">
            <p class="summary-label">Cálculos feitos</p>
            <p class="summary-value green">${history.length}</p>
            <p class="summary-footnote">no histórico</p>
          </div>
        </div>
        <p class="subtitle last-access">Último acesso: ${formatDate(session.lastAccess)}</p>

        <h2 class="section-header">Atalhos</h2>
        <div class="card list-card">
          ${shortcutRow('calculator', 'calculator', 'Calcular TMB', '')}
          <div class="divider inset"></div>
          ${shortcutRow('history', 'history', 'Ver histórico', 'orange')}
          <div class="divider inset"></div>
          ${shortcutRow('profile', 'profile', 'Meu perfil', 'green')}
        </div>
      </div>
    </section>
  `
}

function shortcutRow(route, iconName, label, tone) {
  return `
    <button class="row clickable" data-route="${route}" type="button">
      <span class="row-icon ${tone}">${icon(iconName)}</span>
      <span class="body-text row-label">${label}</span>
      ${icon('chevron', 'chevron')}
    </button>
  `
}

function calculatorTemplate() {
  return `
    <section class="screen">
      <div class="screen-content">
        <h1 class="large-title">Metabolismo</h1>
        <p class="subtitle">Calcule sua Taxa Metabólica Basal</p>

        <h2 class="section-header first">Seus dados</h2>
        <div class="card data-card">
          ${metricRow('weight', 'Peso', '70', 'kg', 'decimal')}
          <div class="divider"></div>
          ${metricRow('height', 'Altura', '170', 'cm', 'decimal')}
          <div class="divider"></div>
          ${metricRow('age', 'Idade', '25', 'anos', 'numeric')}
        </div>

        <h2 class="section-header">Sexo</h2>
        <div class="segments" role="group" aria-label="Sexo">
          <button class="segment ${state.sex === 'Masculino' ? 'active' : ''}" data-sex="Masculino" type="button">Masculino</button>
          <button class="segment ${state.sex === 'Feminino' ? 'active' : ''}" data-sex="Feminino" type="button">Feminino</button>
        </div>

        <button class="primary-button calculate-button" id="calculate" type="button">Calcular</button>

        ${
          state.result === null
            ? ''
            : `<div class="card result-card" id="result-card">
                <p class="subtitle">Sua taxa metabólica basal</p>
                <p class="result-value">${state.result}</p>
                <p class="subtitle">kcal por dia</p>
              </div>`
        }
      </div>
    </section>
  `
}

function metricRow(id, label, placeholder, unit, inputMode) {
  return `
    <label class="metric-row">
      <span class="metric-label">${label}</span>
      <input class="metric-input" id="${id}" type="text" inputmode="${inputMode}" placeholder="${placeholder}" aria-label="${label}">
      <span class="metric-unit">${unit}</span>
    </label>
  `
}

function bindCalculator() {
  document.querySelectorAll('[data-sex]').forEach((button) => {
    button.addEventListener('click', () => {
      state.sex = button.dataset.sex
      document.querySelectorAll('[data-sex]').forEach((item) => item.classList.toggle('active', item === button))
    })
  })
  document.querySelector('#calculate').addEventListener('click', () => {
    const weight = parseFloat(document.querySelector('#weight').value.replace(',', '.'))
    const height = parseFloat(document.querySelector('#height').value.replace(',', '.'))
    const age = parseInt(document.querySelector('#age').value, 10)
    if (![weight, height, age].every(Number.isFinite) || weight <= 0 || height <= 0 || age <= 0) {
      state.result = null
      showToast('Preencha todos os campos com valores válidos')
      return
    }
    const tmb =
      state.sex === 'Masculino'
        ? 66 + 13.7 * weight + 5 * height - 6.8 * age
        : 655 + 9.6 * weight + 1.8 * height - 4.7 * age
    state.result = Math.round(tmb)
    addHistory(tmb, state.sex)
    renderApp()
    requestAnimationFrame(() => document.querySelector('#result-card')?.scrollIntoView({ behavior: 'smooth' }))
  })
}

function historyTemplate() {
  const newestFirst = getHistory()
  if (!newestFirst.length) {
    return `
      <section class="screen">
        <div class="screen-content">
          <h1 class="large-title">Histórico</h1>
          <p class="subtitle">A evolução da sua TMB</p>
          <div class="card subtitle empty-state">Nenhum cálculo ainda.\nUse a aba Calcular para começar.</div>
        </div>
      </section>
    `
  }

  const chronological = [...newestFirst].reverse()
  const current = chronological.at(-1).tmb
  const variation = current - chronological[0].tmb
  const average = Math.floor(chronological.reduce((sum, item) => sum + item.tmb, 0) / chronological.length)
  const selected = chronological[Math.min(state.selectedHistory, chronological.length - 1)]
  state.selectedHistory = chronological.indexOf(selected)

  return `
    <section class="screen">
      <div class="screen-content">
        <h1 class="large-title">Histórico</h1>
        <p class="subtitle">A evolução da sua TMB</p>

        <div class="history-content">
          <div class="card stats-card">
            ${stat('Atual', current)}
            ${stat('Variação', variation > 0 ? `▲ ${variation}` : variation < 0 ? `▼ ${Math.abs(variation)}` : '0', variation > 0 ? 'up' : variation < 0 ? 'down' : '')}
            ${stat('Média', average)}
          </div>

          <h2 class="section-header">Gasto calórico (kcal)</h2>
          ${chartTemplate(chronological, state.selectedHistory)}
          <p class="subtitle chart-help">Toque ou arraste no gráfico para ver cada cálculo</p>

          <h2 class="section-header">Cálculo selecionado</h2>
          ${historyItem(selected)}
        </div>
      </div>
    </section>
  `
}

function stat(label, value, className = '') {
  return `<div class="stat"><div class="stat-label">${label}</div><div class="stat-value ${className}">${value}</div></div>`
}

function chartTemplate(items, selectedIndex) {
  const width = 420
  const height = 228
  const area = { left: 48, top: 34, right: 410, bottom: 194 }
  const values = items.map((item) => item.tmb)
  const rawMin = Math.min(...values)
  const rawMax = Math.max(...values)
  const gap = Math.max(50, Math.floor((rawMax - rawMin) / 5))
  const min = Math.max(0, Math.floor((rawMin - gap) / 50) * 50)
  const max = Math.floor((rawMax + gap) / 50 + 1) * 50
  const x = (index) =>
    items.length === 1 ? (area.left + area.right) / 2 : area.left + ((area.right - area.left) * index) / (items.length - 1)
  const y = (value) => area.bottom - ((area.bottom - area.top) * (value - min)) / (max - min)
  const points = items.map((item, index) => ({ x: x(index), y: y(item.tmb), item }))

  let line = `M ${points[0].x} ${points[0].y}`
  for (let index = 1; index < points.length; index += 1) {
    const middle = (points[index - 1].x + points[index].x) / 2
    line += ` C ${middle} ${points[index - 1].y}, ${middle} ${points[index].y}, ${points[index].x} ${points[index].y}`
  }
  const areaPath = `${line} L ${points.at(-1).x} ${area.bottom} L ${points[0].x} ${area.bottom} Z`
  const selected = points[selectedIndex]
  const bubbleWidth = 78
  const bubbleX = Math.max(0, Math.min(selected.x - bubbleWidth / 2, width - bubbleWidth))
  const bubbleY = Math.max(0, selected.y - 38)
  const dateCount = Math.min(items.length, 5)
  const dateIndexes = [
    ...new Set(
      Array.from({ length: dateCount }, (_, index) =>
        dateCount === 1 ? items.length - 1 : Math.round((index * (items.length - 1)) / (dateCount - 1)),
      ),
    ),
  ]

  return `
    <div class="card chart-card" id="chart" data-count="${items.length}">
      <svg viewBox="0 0 ${width} ${height}" role="img" aria-label="Evolução da TMB">
        <defs>
          <linearGradient id="areaGradient" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stop-color="var(--accent)" stop-opacity=".33"/>
            <stop offset="100%" stop-color="var(--accent)" stop-opacity="0"/>
          </linearGradient>
        </defs>
        ${[0, 1, 2]
          .map((index) => {
            const value = min + ((max - min) * index) / 2
            const position = y(value)
            return `<line class="chart-grid" x1="${area.left}" y1="${position}" x2="${area.right}" y2="${position}"/><text class="chart-label" x="0" y="${position + 4}">${Math.round(value)}</text>`
          })
          .join('')}
        ${points.length > 1 ? `<path class="chart-area" d="${areaPath}"/><path class="chart-line" d="${line}"/>` : ''}
        <line class="chart-guide" x1="${selected.x}" y1="${area.top}" x2="${selected.x}" y2="${area.bottom}"/>
        ${points
          .map(
            (point, index) =>
              `<circle class="chart-point ${index === selectedIndex ? 'selected' : ''}" data-chart-index="${index}" cx="${point.x}" cy="${point.y}" r="${index === selectedIndex ? 6 : 4}"/>`,
          )
          .join('')}
        <rect class="chart-bubble" x="${bubbleX}" y="${bubbleY}" width="${bubbleWidth}" height="28" rx="14"/>
        <text class="chart-bubble-text" x="${bubbleX + bubbleWidth / 2}" y="${bubbleY + 18}">${selected.item.tmb} kcal</text>
        ${dateIndexes
          .map((index, labelIndex) => {
            const anchor = dateIndexes.length === 1 ? 'middle' : labelIndex === 0 ? 'start' : labelIndex === dateIndexes.length - 1 ? 'end' : 'middle'
            return `<text class="chart-label" x="${points[index].x}" y="${height - 2}" text-anchor="${anchor}">${formatDate(items[index].date, true)}</text>`
          })
          .join('')}
      </svg>
    </div>
  `
}

function historyItem(item) {
  return `
    <button class="history-item clickable" id="history-item" type="button">
      <span class="history-copy">
        <span class="history-sex">${item.sex}</span>
        <span class="history-date">${formatDate(item.date)}</span>
      </span>
      <span class="history-divider"></span>
      <span class="history-value">${item.tmb} kcal</span>
      ${icon('chevron', 'chevron')}
    </button>
  `
}

function bindHistory() {
  const chronological = [...getHistory()].reverse()
  document.querySelectorAll('[data-chart-index]').forEach((point) => {
    point.addEventListener('click', () => selectHistory(Number(point.dataset.chartIndex)))
  })
  const chart = document.querySelector('#chart')
  chart?.addEventListener('pointermove', (event) => {
    if (event.buttons !== 1 && event.pointerType === 'mouse') return
    const rectangle = chart.getBoundingClientRect()
    const relative = (event.clientX - rectangle.left) / rectangle.width
    selectHistory(Math.round(Math.max(0, Math.min(1, relative)) * (chronological.length - 1)))
  })
  document.querySelector('#history-item')?.addEventListener('click', () => {
    openHistoryModal(chronological[state.selectedHistory])
  })
}

function selectHistory(index) {
  if (index === state.selectedHistory) return
  state.selectedHistory = index
  renderApp()
}

function openHistoryModal(item) {
  const maintenance = Math.round(item.tmb * 1.55)
  const steps = [
    ['Manter o peso', `Consuma cerca de ${maintenance} kcal por dia (atividade moderada).`, 'green'],
    ['Perder peso', `Reduza para cerca de ${maintenance - 500} kcal por dia.`, 'orange'],
    ['Ganhar massa', `Aumente para cerca de ${maintenance + 300} kcal por dia.`, ''],
    ['Hidratação', 'Beba pelo menos 2 litros de água ao longo do dia.', ''],
  ]
  const backdrop = document.createElement('div')
  backdrop.className = 'modal-backdrop'
  backdrop.innerHTML = `
    <div class="card modal" role="dialog" aria-modal="true" aria-labelledby="modal-title">
      <div class="modal-icon">${icon('history')}</div>
      <h2 class="modal-value" id="modal-title">${item.tmb} kcal</h2>
      <p class="subtitle">${item.sex} · ${formatDate(item.date)}</p>
      <h3 class="section-header">O que fazer</h3>
      <div class="steps">
        ${steps
          .map(
            ([title, text, tone]) => `
              <div class="step">
                <span class="row-icon ${tone}">${icon('check')}</span>
                <span class="step-copy"><span class="step-title">${title}</span><span class="step-text">${text}</span></span>
              </div>`,
          )
          .join('')}
      </div>
      <button class="primary-button modal-button" id="close-modal" type="button">Entendi</button>
    </div>
  `
  document.body.append(backdrop)
  const close = () => backdrop.remove()
  backdrop.addEventListener('click', (event) => {
    if (event.target === backdrop) close()
  })
  document.querySelector('#close-modal').addEventListener('click', close)
  document.addEventListener(
    'keydown',
    (event) => {
      if (event.key === 'Escape') close()
    },
    { once: true },
  )
}

function profileTemplate() {
  const session = getSession()
  const name = displayName(session.email)
  return `
    <section class="screen">
      <div class="screen-content">
        <h1 class="large-title">Perfil</h1>
        <div class="avatar large">${initials(name)}</div>
        <p class="profile-name">${escapeHtml(name)}</p>

        <h2 class="section-header">Conta</h2>
        <div class="card list-card">
          <div class="row">
            <span class="row-icon">${icon('email')}</span>
            <span class="body-text">Email</span>
            <span class="account-value">${escapeHtml(session.email)}</span>
          </div>
          <div class="divider inset"></div>
          <div class="row">
            <span class="row-icon orange">${icon('history')}</span>
            <span class="body-text">Último acesso</span>
            <span class="account-value">${formatDate(session.lastAccess)}</span>
          </div>
        </div>

        <button class="card row logout-row clickable" id="logout" type="button">
          <span class="row-icon destructive">${icon('logout')}</span>
          <span class="row-label body-text destructive-text">Sair da conta</span>
        </button>
      </div>
    </section>
  `
}

function bindProfile() {
  document.querySelector('#logout').addEventListener('click', () => {
    localStorage.removeItem('tmb_session')
    state.route = 'home'
    state.result = null
    renderLogin()
  })
}

function escapeHtml(value) {
  return String(value)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;')
}

renderApp()
